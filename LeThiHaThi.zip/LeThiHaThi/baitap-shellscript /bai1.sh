#!/bin/bash
echo "Hello"
who
echo "Thu muc hien hanh"
pwd 
echo "Thu muc "
ls -ila 
echo "Ngay gio hien tai"
date 
