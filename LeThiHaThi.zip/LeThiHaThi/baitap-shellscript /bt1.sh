#!/bin/bash
clear
echo "Hello World"
